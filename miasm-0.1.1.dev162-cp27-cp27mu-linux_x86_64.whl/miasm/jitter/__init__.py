"JustInTime compilation feature"
